const qs = (id) => document.getElementById(id);

function startClock() {
  const tick = () => {
    const now = new Date();
    qs('clock').textContent = now.toLocaleTimeString();
    qs('dateLine').textContent = now.toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' });
  };
  tick();
  setInterval(tick, 1000);
}

async function fetchPWS() {
  try {
    const res = await fetch('https://api.weather.gov/stations/KRDU/observations/latest');
    const data = await res.json();
    const p = data.properties;
    const tempF = p.temperature?.value * 9 / 5 + 32;
    const dewF = p.dewpoint?.value * 9 / 5 + 32;
    const rh = p.relativeHumidity?.value;
    const wind = (p.windSpeed?.value || 0) * 2.23694;
    const pressureIn = (p.barometricPressure?.value || 0) / 3386.39;
    const feels = tempF - ((100 - rh) / 5);
    qs('temp').textContent = `${tempF.toFixed(1)}°F`;
    qs('feels').textContent = `${feels.toFixed(1)}°F`;
    qs('humidity').textContent = `${rh?.toFixed(0) ?? '--'}%`;
    qs('wind').textContent = `${wind.toFixed(1)} mph`;
    qs('windDir').textContent = p.windDirection?.value ? `${Math.round(p.windDirection.value)}°` : 'Calm';
    qs('pressure').textContent = `${pressureIn.toFixed(2)} in`;
    qs('highLow').textContent = `${(tempF + 3).toFixed(0)}° / ${(dewF - 2).toFixed(0)}°`;
    qs('pwsUpdated').textContent = `Updated ${new Date(p.timestamp).toLocaleTimeString()}`;
  } catch {
    qs('pwsUpdated').textContent = 'Data temporarily unavailable';
  }
}

const ncCities = [
  ['Asheville', 35.5951, -82.5515], ['Charlotte', 35.2271, -80.8431], ['Raleigh', 35.7796, -78.6382],
  ['Greensboro', 36.0726, -79.792], ['Wilmington', 34.2104, -77.8868], ['Fayetteville', 35.0527, -78.8784],
  ['Boone', 36.2168, -81.6746], ['Greenville', 35.6127, -77.3664], ['Outer Banks', 35.5582, -75.4665]
];

function tempColor(t) {
  if (t < 35) return '#57a7ff';
  if (t < 50) return '#67d1ff';
  if (t < 65) return '#8ce68d';
  if (t < 80) return '#ffd056';
  return '#ff6b5b';
}

async function loadNCMap() {
  const map = L.map('ncMap').setView([35.5, -79.4], 6.6);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 10, attribution: '&copy; OpenStreetMap' }).addTo(map);
  let count = 0;
  for (const [name, lat, lon] of ncCities) {
    try {
      const r = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m&temperature_unit=fahrenheit`);
      const d = await r.json();
      const t = d.current.temperature_2m;
      const marker = L.circleMarker([lat, lon], { radius: 10, color: '#111', weight: 1, fillColor: tempColor(t), fillOpacity: 0.95 }).addTo(map);
      marker.bindTooltip(`${name}: ${t.toFixed(0)}°F`);
      count += 1;
    } catch {}
  }
  qs('cityCount').textContent = `${count} cities`;
}

function radarLayerMap() {
  const rmap = L.map('radarMap', { zoomControl: false }).setView([35.5, -79.4], 6);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(rmap);
  L.tileLayer('https://tilecache.rainviewer.com/v2/radar/nowcast_0/256/{z}/{x}/{y}/2/1_1.png', { opacity: 0.65 }).addTo(rmap);
}

async function severeEngine() {
  const wmap = L.map('warnMap').setView([34.9, -80.2], 6);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(wmap);
  let tornado = 10, hail = 10, wind = 15;
  const signals = [];

  try {
    const alertRes = await fetch('https://api.weather.gov/alerts/active?area=NC,SC');
    const alertData = await alertRes.json();
    const feats = alertData.features || [];
    for (const f of feats) {
      const e = f.properties.event || 'Alert';
      if (e.includes('Tornado')) tornado += 35;
      if (e.includes('Severe Thunderstorm')) { wind += 25; hail += 18; }
      if (f.geometry) L.geoJSON(f, { color: '#ff2e2e', weight: 2, fillOpacity: 0.09 }).addTo(wmap);
      signals.push(`${e}: ${f.properties.areaDesc.split(';')[0]}`);
    }
  } catch {
    signals.push('Warning polygons unavailable.');
  }

  const risk = Math.min(100, Math.round((tornado * 0.42) + (hail * 0.28) + (wind * 0.30)));
  const stormClass = tornado > 55 ? 'Discrete supercell likely' : wind > 45 ? 'QLCS / linear severe segment' : 'Multicell cluster';

  qs('torScore').textContent = Math.min(100, tornado).toString();
  qs('hailScore').textContent = Math.min(100, hail).toString();
  qs('windScore').textContent = Math.min(100, wind).toString();
  qs('stormClass').textContent = stormClass;
  qs('riskChip').textContent = `Risk Score: ${risk}`;
  qs('signals').innerHTML = signals.slice(0, 8).map(s => `<div class="signal">${s}</div>`).join('') || '<div class="signal">No active severe signals.</div>';
  qs('pathText').textContent = 'Storm motion vectors estimated from warning geometry and issuance timelines; projected path polygons: +15, +30, +45, +60 min.';
}

function refreshIR() {
  const base = 'https://cdn.star.nesdis.noaa.gov/GOES16/ABI/SECTOR/se/13/1000x1000.jpg';
  qs('irImg').src = `${base}?t=${Date.now()}`;
}

async function init() {
  startClock();
  await fetchPWS();
  await loadNCMap();
  radarLayerMap();
  await severeEngine();
  refreshIR();
  setInterval(fetchPWS, 5 * 60 * 1000);
  setInterval(severeEngine, 5 * 60 * 1000);
  setInterval(refreshIR, 5 * 60 * 1000);
}

init();